
create procedure "PD_CUBE_STAT" @ioTIME DATETIME
as
begin
	delete from "CUBE_STAT" where "TIME" = @ioTIME;
end;
go

