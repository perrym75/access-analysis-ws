
create procedure "PD_ROLE_CATEGORY" @ioROLE_CATEGORY_ID INTEGER
as
begin
	delete from "ROLE_CATEGORY" where "ROLE_CATEGORY_ID" = @ioROLE_CATEGORY_ID;
end;
GO

