
create procedure "PD_CERTIFICATE" @ioCERTIFICATE_ID INTEGER
as
begin
	delete from "CERTIFICATE" where "CERTIFICATE_ID" = @ioCERTIFICATE_ID;
end;
GO

