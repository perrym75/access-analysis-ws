






create procedure "PD_ACCESS_ENTRY" @ioACCESS_ENTRY_ID INTEGER
as
begin
	delete from "ACCESS_ENTRY" where "ACCESS_ENTRY_ID" = @ioACCESS_ENTRY_ID;
end;
GO

