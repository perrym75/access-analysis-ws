	
	create trigger tIU_V_POST_ROLES on V_POST_ROLES for insert, update
	as
	begin
		if exists( select * from POST inner join inserted on inserted.PARENT_ID = "POST_ID" and IS_DELETED = 1 )
			raiserror( 'Usage deleted object!', 16, 1 );
	end;
  go

