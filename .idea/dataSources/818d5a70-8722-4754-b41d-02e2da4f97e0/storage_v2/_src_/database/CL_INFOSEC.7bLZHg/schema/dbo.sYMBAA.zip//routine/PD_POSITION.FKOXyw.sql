
create procedure "PD_POSITION" @ioPOSITION_ID INTEGER
as
begin
	delete from "POSITION" where "POSITION_ID" = @ioPOSITION_ID;
end;
GO

