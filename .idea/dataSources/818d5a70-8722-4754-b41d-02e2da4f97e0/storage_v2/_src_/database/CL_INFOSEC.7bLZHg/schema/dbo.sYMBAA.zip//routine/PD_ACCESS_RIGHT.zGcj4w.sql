

create procedure "PD_ACCESS_RIGHT" @ioACCESS_RIGHT_ID INTEGER
as
begin
	delete from "ACCESS_RIGHT" where "ACCESS_RIGHT_ID" = @ioACCESS_RIGHT_ID;
end;
GO

