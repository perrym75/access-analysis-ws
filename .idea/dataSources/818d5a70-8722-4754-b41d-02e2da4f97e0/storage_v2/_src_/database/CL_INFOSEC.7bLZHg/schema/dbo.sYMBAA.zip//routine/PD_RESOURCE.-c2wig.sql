
create procedure "PD_RESOURCE" @ioRESOURCE_ID INTEGER
as
begin
	delete from "RESOURCE" where "RESOURCE_ID" = @ioRESOURCE_ID;
end;
GO

