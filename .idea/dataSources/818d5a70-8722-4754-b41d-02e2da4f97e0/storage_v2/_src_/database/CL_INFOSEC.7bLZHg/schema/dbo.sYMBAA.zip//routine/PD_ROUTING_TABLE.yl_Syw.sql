
create procedure "PD_ROUTING_TABLE" @ioROUTING_TABLE_ID INTEGER
as
begin
	delete from "ROUTING_TABLE" where "ROUTING_TABLE_ID" = @ioROUTING_TABLE_ID;
end;
GO

