

create view VW_M_DEMAND_DATA as select * from M_DEMAND_DATA;
GO

