	
	create trigger tIU_V_DEPARTMENT_ROLES on V_DEPARTMENT_ROLES for insert, update
	as
	begin
		if exists( select * from DEPARTMENT inner join inserted on inserted.PARENT_ID = "DEPARTMENT_ID" and IS_DELETED = 1 )
			raiserror( 'Usage deleted object!', 16, 1 );
	end;
  go

