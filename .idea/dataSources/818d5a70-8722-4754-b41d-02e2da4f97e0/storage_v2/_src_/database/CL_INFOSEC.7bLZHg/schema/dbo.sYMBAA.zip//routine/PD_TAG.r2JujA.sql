
create procedure "PD_TAG" @ioTAG_ID INTEGER
as
begin
	delete from "TAG" where "TAG_ID" = @ioTAG_ID;
end;
go

