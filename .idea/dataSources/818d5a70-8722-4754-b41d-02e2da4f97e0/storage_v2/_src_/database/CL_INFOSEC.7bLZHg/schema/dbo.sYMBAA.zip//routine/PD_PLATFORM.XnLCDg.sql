
create procedure "PD_PLATFORM" @ioPLATFORM_ID INTEGER
as
begin
	delete from "PLATFORM" where "PLATFORM_ID" = @ioPLATFORM_ID;
end;
GO

