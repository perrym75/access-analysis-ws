
create view VW_ACCESS_LOG as
select "PERSONAGE_ID", "RESOURCE_ID", "ACCESS_RIGHT_ID", "DEMAND_ID", "TYPE" from ACCESS_LOG;
go


create trigger ti_access_log on VW_ACCESS_LOG instead of insert
as
declare 
	@personageID	integer,
	@resourceID		integer,
	@accessrightID	integer,
	@demandID		integer,
	@type			integer,
	@old_type		integer;
begin
	select @personageID = PERSONAGE_ID, @resourceID = RESOURCE_ID, @accessrightID = ACCESS_RIGHT_ID, @demandID = DEMAND_ID, @type = [TYPE] from inserted;
	if exists( select * from ACCESS_LOG where PERSONAGE_ID = @personageID and RESOURCE_ID = @resourceID and ACCESS_RIGHT_ID = @accessrightID and DEMAND_ID = @demandID )
	begin
		select @old_type = [TYPE] from ACCESS_LOG 
			where PERSONAGE_ID = @personageID and RESOURCE_ID = @resourceID and 
				ACCESS_RIGHT_ID = @accessrightID and DEMAND_ID = @demandID;
		if @old_type <> @type begin
			delete ACCESS_LOG where PERSONAGE_ID = @personageID and RESOURCE_ID = @resourceID and 
				ACCESS_RIGHT_ID = @accessrightID and DEMAND_ID = @demandID; 
		end; 
	end
	else
	begin
		insert into ACCESS_LOG( PERSONAGE_ID, RESOURCE_ID, ACCESS_RIGHT_ID, DEMAND_ID, TYPE )
			values( @personageID, @resourceID, @accessrightID, @demandID, @type );
	end;
end;
go

