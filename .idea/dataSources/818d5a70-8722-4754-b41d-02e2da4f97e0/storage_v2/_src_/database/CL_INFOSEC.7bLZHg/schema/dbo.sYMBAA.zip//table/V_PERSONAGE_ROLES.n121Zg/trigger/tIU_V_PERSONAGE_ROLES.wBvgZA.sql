	
	create trigger tIU_V_PERSONAGE_ROLES on V_PERSONAGE_ROLES for insert, update
	as
	begin
		if exists( select * from PERSONAGE inner join inserted on inserted.PARENT_ID = "PERSONAGE_ID" and IS_DELETED = 1 )
			raiserror( 'Usage deleted object!', 16, 1 );
	end;
  go

