
create procedure "PD_DIVERGENCE_LOG" @ioDIVERGENCE_LOG_ID INTEGER
as
begin
	delete from "DIVERGENCE_LOG" where "DIVERGENCE_LOG_ID" = @ioDIVERGENCE_LOG_ID;
end;
GO

