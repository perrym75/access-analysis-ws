
create view VW_M_EMPLOYEE_DATA as select * from M_EMPLOYEE_DATA;
GO

