
create procedure "PD_NET_NODE" @ioNET_NODE_ID INTEGER
as
begin
	delete from "NET_NODE" where "NET_NODE_ID" = @ioNET_NODE_ID;
end;
GO

