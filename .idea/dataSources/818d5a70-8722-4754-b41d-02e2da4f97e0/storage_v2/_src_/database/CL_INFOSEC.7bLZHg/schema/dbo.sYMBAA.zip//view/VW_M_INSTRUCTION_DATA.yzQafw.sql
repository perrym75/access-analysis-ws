
create view VW_M_INSTRUCTION_DATA as select * from M_INSTRUCTION_DATA;
GO

