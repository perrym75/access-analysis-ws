
create procedure "PD_SERVER" @ioSERVER_ID INTEGER
as
begin
	delete from "SERVER" where "SERVER_ID" = @ioSERVER_ID;
end;
GO

