/*****************************************************************************/
/* 24.10.2016                                                                */
/*****************************************************************************/
CREATE trigger ti_access_log on VW_ACCESS_LOG instead of insert
as
begin
	merge into ACCESS_LOG as TARGET using (
		select i.PERSONAGE_ID, i.RESOURCE_ID, i.ACCESS_RIGHT_ID, i.DEMAND_ID, i."TYPE", isnull( q."TYPE", 0 ) OLD_TYPE from inserted i
		left join
			(
				select al."TYPE", al.PERSONAGE_ID, al.RESOURCE_ID, al.ACCESS_RIGHT_ID, dense_rank() over( partition by al.PERSONAGE_ID, al.RESOURCE_ID, al.ACCESS_RIGHT_ID order by dp.END_TIME desc ) DR 
				from ACCESS_LOG al 
				inner join inserted i on al.PERSONAGE_ID = i.PERSONAGE_ID and al.RESOURCE_ID = i.RESOURCE_ID and al.ACCESS_RIGHT_ID = i.ACCESS_RIGHT_ID
				inner join DEMAND_PHASE dp on dp.DEMAND_ID = al.DEMAND_ID and dp.PHASE = 4
			) q on DR = 1 and q.PERSONAGE_ID = i.PERSONAGE_ID and q.RESOURCE_ID = i.RESOURCE_ID and q.ACCESS_RIGHT_ID = i.ACCESS_RIGHT_ID
	) as SOURCE( PERSONAGE_ID, RESOURCE_ID, ACCESS_RIGHT_ID, DEMAND_ID, "TYPE", OLD_TYPE ) on ( SOURCE.PERSONAGE_ID = TARGET.PERSONAGE_ID and SOURCE.RESOURCE_ID = TARGET.RESOURCE_ID and SOURCE.ACCESS_RIGHT_ID = TARGET.ACCESS_RIGHT_ID and SOURCE.DEMAND_ID = TARGET.DEMAND_ID )
	when matched and SOURCE."TYPE" <> TARGET."TYPE" then delete
	when not matched by TARGET and SOURCE."TYPE" <> SOURCE.OLD_TYPE then insert( PERSONAGE_ID, RESOURCE_ID, DEMAND_ID, ACCESS_RIGHT_ID, "TYPE" ) values( SOURCE.PERSONAGE_ID, SOURCE.RESOURCE_ID, SOURCE.DEMAND_ID, SOURCE.ACCESS_RIGHT_ID, SOURCE."TYPE" );
end;
go

