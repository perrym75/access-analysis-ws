


create view VW_M_CERTIFICATE_DATA as select * from M_CERTIFICATE_DATA;
GO

