
create procedure "PD_DEMAND" @ioDEMAND_ID INTEGER
as
begin
	delete from "DEMAND" where "DEMAND_ID" = @ioDEMAND_ID;
end;
GO

