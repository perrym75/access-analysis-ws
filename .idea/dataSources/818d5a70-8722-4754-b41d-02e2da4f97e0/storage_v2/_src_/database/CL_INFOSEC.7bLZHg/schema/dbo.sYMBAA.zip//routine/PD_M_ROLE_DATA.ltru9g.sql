
create procedure "PD_M_ROLE_DATA" @ioPARENT_ID INTEGER,
@ioKEY NVARCHAR
as
begin
	delete from "M_ROLE_DATA" where "PARENT_ID" = @ioPARENT_ID and 
	"KEY" = @ioKEY;
end;
GO

