



create view VW_M_PERSONAGE_DATA as select * from M_PERSONAGE_DATA;
GO

