
create procedure "PD_NET_ROUTE" @ioNET_ROUTE_ID INTEGER
as
begin
	delete from "NET_ROUTE" where "NET_ROUTE_ID" = @ioNET_ROUTE_ID;
end;
GO

