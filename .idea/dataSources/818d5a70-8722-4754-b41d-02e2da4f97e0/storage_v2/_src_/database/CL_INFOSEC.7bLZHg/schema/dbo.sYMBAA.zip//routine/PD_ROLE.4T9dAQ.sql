
create procedure "PD_ROLE" @ioROLE_ID INTEGER
as
begin
	delete from "ROLE" where "ROLE_ID" = @ioROLE_ID;
end;
GO

