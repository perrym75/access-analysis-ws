
create view VW_M_DEPARTMENT_DATA as select * from M_DEPARTMENT_DATA;
GO

