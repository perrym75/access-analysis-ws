/*****************************************************************************/
/* 10.11.2016                                                                */
/*****************************************************************************/
create procedure [PI_AE_WITH_LRR] @SP_ID integer, @RES_ID integer, @ARS nvarchar( 2000 )
as
begin
	;with ListARs( i, AR_ID )
	as
	(
		select CHARINDEX( ',',@ARS ), SUBSTRING( @ARS, 0, CHARINDEX( ',', @ARS ) ) 
		union all
		select CHARINDEX( ',', @ARS, ListARs.i + 1 ), SUBSTRING( @ARS, ListARs.i + 1, ABS( CHARINDEX( ',', @ARS, ListARs.i + 1 ) - ListARs.i ) - 1 )
		from ListARs
		where i > 0
	)
	insert into ACCESS_ENTRY( ACCESS_RIGHT_ID, SECURITY_PRINCIPAL_ID, RESOURCE_ID, EXISTENCE, USAGE_COUNTER ) 
	select AR_ID, @SP_ID, @RES_ID, 1, 1 from ListARs where i > 0;
	;with ListARs( i, AR_ID )
	as
	(
		select CHARINDEX( ',',@ARS ), SUBSTRING( @ARS, 0, CHARINDEX( ',', @ARS ) ) 
		union all
		select CHARINDEX( ',', @ARS, ListARs.i + 1 ), SUBSTRING( @ARS, ListARs.i + 1, ABS( CHARINDEX( ',', @ARS, ListARs.i + 1 ) - ListARs.i ) - 1 )
		from ListARs
		where i > 0
	)
	insert into LINK_ROLE_RESOURCE( ROLE_ID, RESOURCE_ID, ACCESS_RIGHT_ID ) 
	select ROLE_ID, @RES_ID, AR_ID from ListARs 
	inner join ( select ROLE_ID from USER_ACCOUNT where SECURITY_PRINCIPAL_ID = @SP_ID union select ROLE_ID from USER_GROUP_ACCOUNT where SECURITY_PRINCIPAL_ID = @SP_ID ) r on r.ROLE_ID is not null
	where i > 0;
end;
go

