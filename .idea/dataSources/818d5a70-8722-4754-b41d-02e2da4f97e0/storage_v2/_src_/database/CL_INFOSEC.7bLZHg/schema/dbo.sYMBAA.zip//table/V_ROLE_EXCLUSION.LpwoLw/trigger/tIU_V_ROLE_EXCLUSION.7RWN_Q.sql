	
	create trigger tIU_V_ROLE_EXCLUSION on V_ROLE_EXCLUSION for insert, update
	as
	begin
		if exists( select * from ROLE inner join inserted on inserted.PARENT_ID = "ROLE_ID" and IS_DELETED = 1 )
			raiserror( 'Usage deleted object!', 16, 1 );
	end;
  go

