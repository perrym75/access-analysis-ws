


create view VW_M_RESPONSIBILITY_DATA as select * from M_RESPONSIBILITY_DATA;
GO

