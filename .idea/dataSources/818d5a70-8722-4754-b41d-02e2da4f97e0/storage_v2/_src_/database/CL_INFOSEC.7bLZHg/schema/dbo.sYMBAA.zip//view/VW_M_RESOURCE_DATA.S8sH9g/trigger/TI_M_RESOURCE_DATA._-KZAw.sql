
CREATE trigger [TI_M_RESOURCE_DATA] on [VW_M_RESOURCE_DATA] instead of insert
as
declare @tmpValue integer;
begin
	select @tmpValue = len( i.VALUE ) from inserted i;
	if exists( select * from M_RESOURCE_DATA m inner join inserted i on m.PARENT_ID = i.PARENT_ID and m.[KEY] = i.[KEY] ) begin
		if @tmpValue < 129
			update M_RESOURCE_DATA set [VALUE] = i.[VALUE], [VALUE_SHORT] = i.[VALUE]
				from M_RESOURCE_DATA m inner join inserted i on m.PARENT_ID = i.PARENT_ID and m.[KEY] = i.[KEY];
		else
			update M_RESOURCE_DATA set [VALUE] = i.[VALUE], [VALUE_SHORT] = null
				from M_RESOURCE_DATA m inner join inserted i on m.PARENT_ID = i.PARENT_ID and m.[KEY] = i.[KEY];
	end
	else begin
		if @tmpValue < 129
			insert into M_RESOURCE_DATA( [PARENT_ID], [KEY], [VALUE], [VALUE_SHORT] )  select [PARENT_ID], [KEY], [VALUE], [VALUE] from inserted;
		else
			insert into M_RESOURCE_DATA( [PARENT_ID], [KEY], [VALUE] )  select [PARENT_ID], [KEY], [VALUE] from inserted;
	end;
end;
GO

