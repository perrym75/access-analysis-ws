
create view VW_M_NET_OBJECT_DATA as select * from M_NET_OBJECT_DATA;
GO

