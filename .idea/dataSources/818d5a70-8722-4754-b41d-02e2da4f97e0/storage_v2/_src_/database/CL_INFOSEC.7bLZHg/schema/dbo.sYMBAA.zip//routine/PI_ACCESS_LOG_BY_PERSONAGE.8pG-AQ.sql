
create procedure PI_ACCESS_LOG_BY_PERSONAGE @par_personage integer, @par_resource integer, @par_access_right integer, @par_demand integer, @par_type integer
as
begin
    ;with TreeRoles( PARENT_ID, CHILD_ID, LEV )
    as
    (
        select ROLE_ID, ROLE_ID, 0 from ROLE 
        union all
        select tr.PARENT_ID, vrr.VALUE_ID, tr.LEV + 1 from V_ROLE_ROLES vrr inner join TreeRoles tr on tr.CHILD_ID = vrr.PARENT_ID
    )
    insert into "VW_ACCESS_LOG" ( "PERSONAGE_ID", "RESOURCE_ID", "ACCESS_RIGHT_ID", "DEMAND_ID", "TYPE" )
    select PERSONAGE_ID, @par_resource, @par_access_right, @par_demand, @par_type  
    from (
        select vpers.VALUE_ID, @par_personage PERSONAGE_ID from V_PERSONAGE_ROLES vpers where vpers.PARENT_ID = @par_personage
        union
        select vpost.VALUE_ID, @par_personage PERSONAGE_ID from PERSONAGE p inner join V_POST_ROLES vpost on p.POST_ID = vpost.PARENT_ID where p.PERSONAGE_ID = @par_personage
        ) q
    left join TreeRoles tr on tr.PARENT_ID = q.VALUE_ID
    left join LINK_ROLE_RESOURCE lrr on tr.CHILD_ID = lrr.ROLE_ID and ACCESS_RIGHT_ID = @par_access_right and RESOURCE_ID = @par_resource
    group by PERSONAGE_ID having sum( case when lrr.LINK_ROLE_RESOURCE_ID is not null then 1 else 0 end ) = 0;
end;
go

