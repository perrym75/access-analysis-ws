
create procedure "PD_POST" @ioPOST_ID INTEGER
as
begin
	delete from "POST" where "POST_ID" = @ioPOST_ID;
end;
GO

