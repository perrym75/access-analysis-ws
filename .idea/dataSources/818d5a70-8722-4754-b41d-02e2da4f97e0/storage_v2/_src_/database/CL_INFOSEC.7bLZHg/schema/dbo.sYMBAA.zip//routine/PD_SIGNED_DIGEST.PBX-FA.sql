
create procedure "PD_SIGNED_DIGEST" @ioSIGNED_DIGEST_ID INTEGER
as
begin
	delete from "SIGNED_DIGEST" where "SIGNED_DIGEST_ID" = @ioSIGNED_DIGEST_ID;
end;
GO

