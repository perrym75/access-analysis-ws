
create trigger [TU_M_RESOURCE_DATA] on [VW_M_RESOURCE_DATA] instead of update
as
declare @tmpValue integer;
declare @tmpId integer;
declare @tmpKey nvarchar( 64 );
begin
	select @tmpValue = len( i.VALUE ), @tmpId = i.PARENT_ID from inserted i;
	if @tmpValue < 129
		update mrd set VALUE = i.VALUE, VALUE_SHORT = i.VALUE from M_RESOURCE_DATA mrd inner join inserted i on mrd.PARENT_ID = i.PARENT_ID where mrd.[KEY] = i.[KEY];
	else
		update mrd set VALUE = i.VALUE, VALUE_SHORT = null from M_RESOURCE_DATA mrd inner join inserted i on mrd.PARENT_ID = i.PARENT_ID where mrd.[KEY] = i.[KEY];
end;
GO

