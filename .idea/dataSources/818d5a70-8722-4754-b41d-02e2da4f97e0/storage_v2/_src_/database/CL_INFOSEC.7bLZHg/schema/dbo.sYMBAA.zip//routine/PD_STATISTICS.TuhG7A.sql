
create procedure "PD_STATISTICS" @ioSTATISTICS_ID INTEGER
as
begin
	delete from "STATISTICS" where "STATISTICS_ID" = @ioSTATISTICS_ID;
end;
GO

