
create view VW_M_SECURITY_RULE_DATA as select * from M_SECURITY_RULE_DATA;
GO

