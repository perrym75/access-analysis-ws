
create procedure "PD_DEPARTMENT" @ioDEPARTMENT_ID INTEGER
as
begin
	delete from "DEPARTMENT" where "DEPARTMENT_ID" = @ioDEPARTMENT_ID;
end;
GO

