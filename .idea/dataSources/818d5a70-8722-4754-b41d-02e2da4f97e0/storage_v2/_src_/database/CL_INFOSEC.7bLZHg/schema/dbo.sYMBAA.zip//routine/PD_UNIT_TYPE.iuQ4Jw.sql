
create procedure "PD_UNIT_TYPE" @ioUNIT_TYPE_ID INTEGER
as
begin
	delete from "UNIT_TYPE" where "UNIT_TYPE_ID" = @ioUNIT_TYPE_ID;
end;
GO

