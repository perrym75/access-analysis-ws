	
	create trigger tIU_V_DPHI_RESPONSIBILITY on V_DPHI_RESPONSIBILITY for insert, update
	as
	begin
		if exists( select * from DEMAND_PHASE_ITEM inner join inserted on inserted.PARENT_ID = "DEMAND_PHASE_ITEM_ID" and IS_DELETED = 1 )
			raiserror( 'Usage deleted object!', 16, 1 );
	end;
  go

