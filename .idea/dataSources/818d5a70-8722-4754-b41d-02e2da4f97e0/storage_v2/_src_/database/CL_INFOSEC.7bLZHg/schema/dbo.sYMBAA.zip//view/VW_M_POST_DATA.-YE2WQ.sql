
create view VW_M_POST_DATA as select * from M_POST_DATA;
GO

