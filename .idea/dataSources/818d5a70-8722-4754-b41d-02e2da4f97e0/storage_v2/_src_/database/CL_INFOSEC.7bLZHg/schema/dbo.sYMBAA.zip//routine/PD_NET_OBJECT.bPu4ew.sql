
create procedure "PD_NET_OBJECT" @ioNET_OBJECT_ID INTEGER
as
begin
	delete from "NET_OBJECT" where "NET_OBJECT_ID" = @ioNET_OBJECT_ID;
end;
GO

