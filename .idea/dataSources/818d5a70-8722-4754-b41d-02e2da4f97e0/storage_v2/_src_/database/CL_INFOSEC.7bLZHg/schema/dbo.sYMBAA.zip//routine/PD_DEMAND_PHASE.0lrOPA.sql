
create procedure "PD_DEMAND_PHASE" @ioDEMAND_PHASE_ID INTEGER
as
begin
	delete from "DEMAND_PHASE" where "DEMAND_PHASE_ID" = @ioDEMAND_PHASE_ID;
end;
GO

