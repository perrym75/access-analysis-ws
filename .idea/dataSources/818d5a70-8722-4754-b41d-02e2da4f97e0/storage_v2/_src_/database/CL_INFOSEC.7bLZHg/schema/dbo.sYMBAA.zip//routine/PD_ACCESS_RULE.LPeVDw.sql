
create procedure "PD_ACCESS_RULE" @ioACCESS_RULE_ID INTEGER
as
begin
	delete from "ACCESS_RULE" where "ACCESS_RULE_ID" = @ioACCESS_RULE_ID;
end;
GO

