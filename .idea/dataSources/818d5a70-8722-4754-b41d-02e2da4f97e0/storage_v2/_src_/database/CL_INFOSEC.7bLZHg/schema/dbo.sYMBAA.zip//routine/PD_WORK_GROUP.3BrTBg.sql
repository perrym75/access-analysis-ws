

















































create procedure "PD_WORK_GROUP" @ioWORK_GROUP_ID INTEGER
as
begin
	delete from "WORK_GROUP" where "WORK_GROUP_ID" = @ioWORK_GROUP_ID;
end;
GO

