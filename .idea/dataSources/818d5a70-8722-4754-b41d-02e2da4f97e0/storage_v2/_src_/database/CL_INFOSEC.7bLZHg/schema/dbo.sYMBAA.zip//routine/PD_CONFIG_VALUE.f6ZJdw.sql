
create procedure "PD_CONFIG_VALUE" @ioNAME NVARCHAR
as
begin
	delete from "CONFIG_VALUE" where "NAME" = @ioNAME;
end;
GO

