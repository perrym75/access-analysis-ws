
create procedure "PD_PERSONAGE" @ioPERSONAGE_ID INTEGER
as
begin
	delete from "PERSONAGE" where "PERSONAGE_ID" = @ioPERSONAGE_ID;
end;
GO

