
create procedure "PD_NAT_RULE" @ioNAT_RULE_ID INTEGER
as
begin
	delete from "NAT_RULE" where "NAT_RULE_ID" = @ioNAT_RULE_ID;
end;
GO

