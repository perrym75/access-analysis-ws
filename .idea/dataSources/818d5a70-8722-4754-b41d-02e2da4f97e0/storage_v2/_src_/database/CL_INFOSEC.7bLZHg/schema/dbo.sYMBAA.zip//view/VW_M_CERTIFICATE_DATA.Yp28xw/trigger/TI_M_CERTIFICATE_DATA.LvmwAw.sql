
CREATE trigger TI_M_CERTIFICATE_DATA on VW_M_CERTIFICATE_DATA instead of insert
as
begin
	if exists( select * from M_CERTIFICATE_DATA m inner join inserted i on m.PARENT_ID = i.PARENT_ID and m.[KEY] = i.[KEY] )
		update M_CERTIFICATE_DATA set [VALUE] = i.[VALUE]
			from M_CERTIFICATE_DATA m inner join inserted i on m.PARENT_ID = i.PARENT_ID and m.[KEY] = i.[KEY];
	else
		insert into M_CERTIFICATE_DATA( [PARENT_ID], [KEY], [VALUE] ) select [PARENT_ID], [KEY], [VALUE] from inserted;
end;
GO

