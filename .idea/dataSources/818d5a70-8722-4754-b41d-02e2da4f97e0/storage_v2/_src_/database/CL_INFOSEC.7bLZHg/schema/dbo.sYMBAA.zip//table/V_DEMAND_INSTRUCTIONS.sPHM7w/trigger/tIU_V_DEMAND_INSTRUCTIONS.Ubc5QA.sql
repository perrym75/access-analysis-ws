	
	create trigger tIU_V_DEMAND_INSTRUCTIONS on V_DEMAND_INSTRUCTIONS for insert, update
	as
	begin
		if exists( select * from DEMAND inner join inserted on inserted.PARENT_ID = "DEMAND_ID" and IS_DELETED = 1 )
			raiserror( 'Usage deleted object!', 16, 1 );
	end;
  go

