
create procedure "PD_RESOURCE_TYPE" @ioRESOURCE_TYPE_ID INTEGER
as
begin
	delete from "RESOURCE_TYPE" where "RESOURCE_TYPE_ID" = @ioRESOURCE_TYPE_ID;
end;
GO

