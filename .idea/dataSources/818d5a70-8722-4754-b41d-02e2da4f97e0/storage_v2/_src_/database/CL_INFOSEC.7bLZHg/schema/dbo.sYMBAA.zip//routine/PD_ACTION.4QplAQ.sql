
create procedure "PD_ACTION" @ioACTION_ID INTEGER
as
begin
	delete from "ACTION" where "ACTION_ID" = @ioACTION_ID;
end;
GO

