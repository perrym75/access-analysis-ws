
create procedure "PD_M_PLATFORM_ATTACHMENTS" @ioPARENT_ID INTEGER,
@ioKEY NVARCHAR
as
begin
	delete from "M_PLATFORM_ATTACHMENTS" where "PARENT_ID" = @ioPARENT_ID and 
	"KEY" = @ioKEY;
end;
GO

