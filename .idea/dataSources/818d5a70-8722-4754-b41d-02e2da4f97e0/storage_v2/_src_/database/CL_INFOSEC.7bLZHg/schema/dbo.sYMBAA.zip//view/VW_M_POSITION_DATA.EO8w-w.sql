
create view VW_M_POSITION_DATA as select * from M_POSITION_DATA;
GO

