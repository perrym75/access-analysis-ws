
create procedure "PD_M_INSTRUCTION_DATA" @ioPARENT_ID INTEGER,
@ioKEY NVARCHAR
as
begin
	delete from "M_INSTRUCTION_DATA" where "PARENT_ID" = @ioPARENT_ID and 
	"KEY" = @ioKEY;
end;
GO

