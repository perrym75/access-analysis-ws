
create procedure "PD_PROTOCOL" @ioPROTOCOL_ID INTEGER
as
begin
	delete from "PROTOCOL" where "PROTOCOL_ID" = @ioPROTOCOL_ID;
end;
GO

