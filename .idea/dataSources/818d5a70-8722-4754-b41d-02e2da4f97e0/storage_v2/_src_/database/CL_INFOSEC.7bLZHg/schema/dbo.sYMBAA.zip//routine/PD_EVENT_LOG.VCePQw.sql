
create procedure "PD_EVENT_LOG" @ioEVENT_LOG_ID INTEGER
as
begin
	delete from "EVENT_LOG" where "EVENT_LOG_ID" = @ioEVENT_LOG_ID;
end;
GO

