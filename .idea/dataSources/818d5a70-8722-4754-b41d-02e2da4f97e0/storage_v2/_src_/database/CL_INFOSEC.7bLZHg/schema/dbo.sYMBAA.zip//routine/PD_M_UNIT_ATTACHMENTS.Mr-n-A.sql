create procedure "PD_M_UNIT_ATTACHMENTS" @ioPARENT_ID INTEGER,
		@ioKEY NVARCHAR
		as
		begin
			delete from "M_UNIT_ATTACHMENTS" where "PARENT_ID" = @ioPARENT_ID and 
			"KEY" = @ioKEY;
		end;
go

