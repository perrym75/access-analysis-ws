

create view VW_M_USER_ACCOUNT_DATA as select * from M_USER_ACCOUNT_DATA;
GO

