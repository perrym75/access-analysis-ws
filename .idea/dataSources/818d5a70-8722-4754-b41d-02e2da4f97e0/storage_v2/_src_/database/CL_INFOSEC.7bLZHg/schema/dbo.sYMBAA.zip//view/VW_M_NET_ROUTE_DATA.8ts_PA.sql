
create view VW_M_NET_ROUTE_DATA as select * from M_NET_ROUTE_DATA;
GO

