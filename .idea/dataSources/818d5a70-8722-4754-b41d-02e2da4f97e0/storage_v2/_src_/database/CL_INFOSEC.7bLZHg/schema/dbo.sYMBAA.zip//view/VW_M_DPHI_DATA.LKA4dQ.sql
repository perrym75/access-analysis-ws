

create view VW_M_DPHI_DATA as select * from M_DPHI_DATA;
GO

