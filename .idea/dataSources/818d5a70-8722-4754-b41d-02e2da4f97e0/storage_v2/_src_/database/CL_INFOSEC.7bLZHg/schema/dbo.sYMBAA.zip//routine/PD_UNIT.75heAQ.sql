
create procedure "PD_UNIT" @ioUNIT_ID INTEGER
as
begin
	delete from "UNIT" where "UNIT_ID" = @ioUNIT_ID;
end;
GO

