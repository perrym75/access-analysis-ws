
create procedure "PD_USER_ACCOUNT" @ioUSER_ACCOUNT_ID INTEGER
as
begin
	delete from "USER_ACCOUNT" where "USER_ACCOUNT_ID" = @ioUSER_ACCOUNT_ID;
end;
GO

