create procedure "PD_M_SP_ATTACHMENTS" @ioPARENT_ID INTEGER,
		@ioKEY NVARCHAR
		as
		begin
			delete from "M_SP_ATTACHMENTS" where "PARENT_ID" = @ioPARENT_ID and 
			"KEY" = @ioKEY;
		end;
go

