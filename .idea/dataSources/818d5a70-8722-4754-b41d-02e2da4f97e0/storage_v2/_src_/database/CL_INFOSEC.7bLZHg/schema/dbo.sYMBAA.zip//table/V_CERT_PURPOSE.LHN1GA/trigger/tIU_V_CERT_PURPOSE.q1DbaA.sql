	
	create trigger tIU_V_CERT_PURPOSE on V_CERT_PURPOSE for insert, update
	as
	begin
		if exists( select * from CERTIFICATE inner join inserted on inserted.PARENT_ID = "CERTIFICATE_ID" and IS_DELETED = 1 )
			raiserror( 'Usage deleted object!', 16, 1 );
	end;
  go

