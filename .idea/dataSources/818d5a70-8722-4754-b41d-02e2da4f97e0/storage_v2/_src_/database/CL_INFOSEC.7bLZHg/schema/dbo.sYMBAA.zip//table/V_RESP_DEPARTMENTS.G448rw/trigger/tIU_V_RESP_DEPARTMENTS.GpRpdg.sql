	
	create trigger tIU_V_RESP_DEPARTMENTS on V_RESP_DEPARTMENTS for insert, update
	as
	begin
		if exists( select * from RESPONSIBILITY inner join inserted on inserted.PARENT_ID = "RESPONSIBILITY_ID" and IS_DELETED = 1 )
			raiserror( 'Usage deleted object!', 16, 1 );
	end;
  go

