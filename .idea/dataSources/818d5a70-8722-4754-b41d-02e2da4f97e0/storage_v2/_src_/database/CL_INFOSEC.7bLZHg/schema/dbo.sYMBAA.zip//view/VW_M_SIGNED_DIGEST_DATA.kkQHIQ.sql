


create view VW_M_SIGNED_DIGEST_DATA as select * from M_SIGNED_DIGEST_DATA;
GO

