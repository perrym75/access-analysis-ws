
create procedure "PD_M_POSITION_DATA" @ioPARENT_ID INTEGER,
@ioKEY NVARCHAR
as
begin
	delete from "M_POSITION_DATA" where "PARENT_ID" = @ioPARENT_ID and 
	"KEY" = @ioKEY;
end;
GO

