


create view VW_M_DIVERGENCE_LOG_DATA as select * from M_DIVERGENCE_LOG_DATA;
GO

