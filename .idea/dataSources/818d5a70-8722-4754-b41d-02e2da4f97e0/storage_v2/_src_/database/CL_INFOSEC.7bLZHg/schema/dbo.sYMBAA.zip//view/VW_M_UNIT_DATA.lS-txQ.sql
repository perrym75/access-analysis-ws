

create view VW_M_UNIT_DATA as select * from M_UNIT_DATA;
GO

