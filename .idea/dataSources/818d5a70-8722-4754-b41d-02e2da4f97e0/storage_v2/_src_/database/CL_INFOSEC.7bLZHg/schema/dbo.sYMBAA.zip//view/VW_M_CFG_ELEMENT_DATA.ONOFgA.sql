


create view VW_M_CFG_ELEMENT_DATA as select * from M_CFG_ELEMENT_DATA;
GO

