	
	create trigger tIU_V_INSTRUCT_KEY on V_INSTRUCT_KEY for insert, update
	as
	begin
		if exists( select * from INSTRUCTION inner join inserted on inserted.PARENT_ID = "INSTRUCTION_ID" and IS_DELETED = 1 )
			raiserror( 'Usage deleted object!', 16, 1 );
	end;
  go

