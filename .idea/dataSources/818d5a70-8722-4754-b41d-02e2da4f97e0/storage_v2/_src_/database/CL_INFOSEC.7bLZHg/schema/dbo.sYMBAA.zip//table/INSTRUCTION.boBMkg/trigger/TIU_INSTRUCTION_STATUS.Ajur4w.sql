
create trigger TIU_INSTRUCTION_STATUS on INSTRUCTION after insert, update
as
begin
	set nocount on;
	insert into H_INSTRUCTION_STATUS( INSTRUCTION_ID, STATUS ) 
	select i.INSTRUCTION_ID, i.STATUS from inserted i left join deleted d on d.INSTRUCTION_ID = i.INSTRUCTION_ID where d.STATUS is null or d.STATUS <> i.STATUS;
end;
go

