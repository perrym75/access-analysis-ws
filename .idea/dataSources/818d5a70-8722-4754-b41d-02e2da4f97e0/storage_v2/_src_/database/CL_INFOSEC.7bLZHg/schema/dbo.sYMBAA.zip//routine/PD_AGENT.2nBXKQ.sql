
create procedure "PD_AGENT" @ioAGENT_ID INTEGER
as
begin
	delete from "AGENT" where "AGENT_ID" = @ioAGENT_ID;
end;
GO

