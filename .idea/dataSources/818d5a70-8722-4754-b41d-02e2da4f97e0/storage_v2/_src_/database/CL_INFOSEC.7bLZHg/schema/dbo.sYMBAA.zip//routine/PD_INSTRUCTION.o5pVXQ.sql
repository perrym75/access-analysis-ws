
create procedure "PD_INSTRUCTION" @ioINSTRUCTION_ID INTEGER
as
begin
	delete from "INSTRUCTION" where "INSTRUCTION_ID" = @ioINSTRUCTION_ID;
end;
GO

