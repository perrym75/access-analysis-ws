
create procedure "PD_NET_USER" @ioNET_USER_ID INTEGER
as
begin
	delete from "NET_USER" where "NET_USER_ID" = @ioNET_USER_ID;
end;
GO

