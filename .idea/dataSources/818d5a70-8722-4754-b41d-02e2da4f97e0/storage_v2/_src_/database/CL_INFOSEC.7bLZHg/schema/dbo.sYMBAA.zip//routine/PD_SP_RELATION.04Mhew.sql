
create procedure "PD_SP_RELATION" @ioSP_RELATION_ID INTEGER
as
begin
	delete from "SP_RELATION" where "SP_RELATION_ID" = @ioSP_RELATION_ID;
end;
GO

