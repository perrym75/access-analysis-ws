
create procedure "PD_NET_TRACE_RULE" @ioNET_TRACE_RULE_ID INTEGER
as
begin
	delete from "NET_TRACE_RULE" where "NET_TRACE_RULE_ID" = @ioNET_TRACE_RULE_ID;
end;
GO

