
create view VW_M_PLATFORM_DATA as select * from M_PLATFORM_DATA;
GO

