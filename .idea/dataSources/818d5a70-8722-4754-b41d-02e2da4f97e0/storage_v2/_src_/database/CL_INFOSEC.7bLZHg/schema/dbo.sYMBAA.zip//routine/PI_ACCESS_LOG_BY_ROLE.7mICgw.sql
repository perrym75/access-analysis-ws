
create procedure PI_ACCESS_LOG_BY_ROLE @par_role integer, @par_resource integer, @par_access_right integer, @par_demand integer, @par_type integer
as
declare
	@var_pers	integer,
	@var_roles	integer,
	@var_rights	integer,
	@var_sum_rights	integer;
declare
	cur_pers cursor for 
		with tree( PARENT_ID, CHILD_ID ) as 
		(
			( 
				select vrr.PARENT_ID, vrr.VALUE_ID from V_ROLE_ROLES vrr where vrr.VALUE_ID = @par_role 
				union 
				select @par_role, @par_role 
			)
			union all
			select vrr.PARENT_ID, vrr.VALUE_ID from V_ROLE_ROLES vrr
				inner join tree on tree.PARENT_ID = vrr.VALUE_ID 
		) 
		select p.PERSONAGE_ID from tree 
		left join V_POST_ROLES vpost on tree.PARENT_ID = vpost.VALUE_ID
		left join V_PERSONAGE_ROLES vpers on tree.PARENT_ID = vpers.VALUE_ID
		inner join PERSONAGE p on p.PERSONAGE_ID = vpers.PARENT_ID
		union
		select p.PERSONAGE_ID from tree 
		left join V_POST_ROLES vpost on tree.PARENT_ID = vpost.VALUE_ID
		left join V_PERSONAGE_ROLES vpers on tree.PARENT_ID = vpers.VALUE_ID
		inner join PERSONAGE p on p.POST_ID = vpost.PARENT_ID
declare
	cur_roles cursor for
		select vpers.VALUE_ID from V_PERSONAGE_ROLES vpers where vpers.PARENT_ID = @var_pers
		union 
		select vpost.VALUE_ID from PERSONAGE p inner join V_POST_ROLES vpost on p.POST_ID = vpost.PARENT_ID where p.PERSONAGE_ID = @var_pers;
begin
	open cur_pers;
	fetch next from cur_pers into @var_pers;
	while @@fetch_status = 0
	begin
        set @var_sum_rights = 0;
        open cur_roles;
        fetch next from cur_roles into @var_roles;
		while @@fetch_status = 0 begin
			with tree( PARENT_ID, VALUE_ID ) as
			(
				select vrr.PARENT_ID, vrr.VALUE_ID from V_ROLE_ROLES vrr where vrr.PARENT_ID = @var_roles
				union all
				select vrr.PARENT_ID, vrr.VALUE_ID from V_ROLE_ROLES vrr 
					inner join tree on tree.VALUE_ID = vrr.PARENT_ID
			) select @var_rights = count( distinct tree.VALUE_ID ) from tree
			inner join LINK_ROLE_RESOURCE lrr on tree.VALUE_ID = lrr.ROLE_ID where ACCESS_RIGHT_ID = @par_access_right and RESOURCE_ID = @par_resource and ROLE_ID <> @par_role
            set @var_sum_rights = @var_sum_rights + @var_rights;
	        fetch next from cur_roles into @var_roles;
		end;     
        if @var_sum_rights = 0 begin
			insert into "VW_ACCESS_LOG" ( "PERSONAGE_ID", "RESOURCE_ID", "ACCESS_RIGHT_ID", "DEMAND_ID", "TYPE" )
            	values( @var_pers, @par_resource, @par_access_right, @par_demand, @par_type );
        end;
		close cur_roles;
		fetch next from cur_pers into @var_pers;
    end;
end;
GO

