
create procedure PI_ACCESS_LOG_BY_ROLE @par_role integer, @par_resource integer, @par_access_right integer, @par_demand integer, @par_type integer
as
begin
    ;with TreeRoles( PARENT_ID, CHILD_ID, LEV )
    as
    (
        select ROLE_ID, ROLE_ID, 0 from ROLE where ROLE_ID = @par_role
        union all
        select vrr.PARENT_ID, tr.CHILD_ID, tr.LEV + 1 from V_ROLE_ROLES vrr inner join TreeRoles tr on tr.PARENT_ID = vrr.VALUE_ID
    ),
    AllPersonages( PERSONAGE_ID )
    as
    (
        select vpr.PARENT_ID PERSONAGE_ID
        from TreeRoles tr
        inner join V_PERSONAGE_ROLES vpr on vpr.VALUE_ID = tr.PARENT_ID 
        where tr.CHILD_ID = @par_role
        union
        select pers.PERSONAGE_ID
        from TreeRoles tr
        inner join V_POST_ROLES vpr on vpr.VALUE_ID = tr.PARENT_ID
        inner join PERSONAGE pers on pers.POST_ID = vpr.PARENT_ID 
        where tr.CHILD_ID = @par_role
    ),
    TreeRoles2( PARENT_ID, CHILD_ID, LEV)
    as
    (
        select ROLE_ID, ROLE_ID, 0 from ROLE 
        union all
        select tr.PARENT_ID, vrr.VALUE_ID, tr.LEV + 1 from V_ROLE_ROLES vrr inner join TreeRoles2 tr on tr.CHILD_ID = vrr.PARENT_ID
    )
    insert into "VW_ACCESS_LOG" ( "PERSONAGE_ID", "RESOURCE_ID", "ACCESS_RIGHT_ID", "DEMAND_ID", "TYPE" )
    select PERSONAGE_ID, @par_resource, @par_access_right, @par_demand, @par_type  
    from (
        select vpers.VALUE_ID, ap.PERSONAGE_ID from V_PERSONAGE_ROLES vpers inner join AllPersonages ap on ap.PERSONAGE_ID = vpers.PARENT_ID
        union
        select vpost.VALUE_ID, ap2.PERSONAGE_ID from PERSONAGE p inner join V_POST_ROLES vpost on p.POST_ID = vpost.PARENT_ID inner join AllPersonages ap2 on ap2.PERSONAGE_ID = p.PERSONAGE_ID
        ) q
    left join TreeRoles2 tr2 on tr2.PARENT_ID = q.VALUE_ID
    left join LINK_ROLE_RESOURCE lrr on tr2.CHILD_ID = lrr.ROLE_ID and ACCESS_RIGHT_ID = @par_access_right and RESOURCE_ID = @par_resource and ROLE_ID <> @par_role
    group by PERSONAGE_ID having sum( case when lrr.LINK_ROLE_RESOURCE_ID is not null then 1 else 0 end ) = 0;
end;
go

