
create trigger TIU_USER_ACCOUNT on USER_ACCOUNT after insert, update
as
	set nocount on;
	update sp set sp.ROLE_ID = inserted.ROLE_ID from SECURITY_PRINCIPAL sp inner join inserted on sp.SECURITY_PRINCIPAL_ID = inserted.SECURITY_PRINCIPAL_ID where sp.SECURITY_PRINCIPAL_ID = inserted.SECURITY_PRINCIPAL_ID;
go

