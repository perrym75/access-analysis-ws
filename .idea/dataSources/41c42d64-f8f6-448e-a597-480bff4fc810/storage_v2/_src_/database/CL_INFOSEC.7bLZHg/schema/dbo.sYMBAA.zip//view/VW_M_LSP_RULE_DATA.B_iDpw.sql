
create view VW_M_LSP_RULE_DATA as select * from M_LSP_RULE_DATA;
GO

