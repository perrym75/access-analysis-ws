
create procedure "PD_EMPLOYEE" @ioEMPLOYEE_ID INTEGER
as
begin
	delete from "EMPLOYEE" where "EMPLOYEE_ID" = @ioEMPLOYEE_ID;
end;
GO

