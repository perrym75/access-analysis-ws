

create view VW_M_NET_NODE_DATA as select * from M_NET_NODE_DATA;
GO

