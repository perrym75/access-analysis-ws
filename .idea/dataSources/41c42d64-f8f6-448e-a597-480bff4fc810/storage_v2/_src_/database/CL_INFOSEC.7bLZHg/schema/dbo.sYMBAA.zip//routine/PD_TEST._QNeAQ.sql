
create procedure "PD_TEST" @ioTEST_ID INTEGER
as
begin
	delete from "TEST" where "TEST_ID" = @ioTEST_ID;
end;
GO

