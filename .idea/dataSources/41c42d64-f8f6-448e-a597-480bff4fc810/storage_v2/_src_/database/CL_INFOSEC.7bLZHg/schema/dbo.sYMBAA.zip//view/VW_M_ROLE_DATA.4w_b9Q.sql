

create view VW_M_ROLE_DATA as select * from M_ROLE_DATA;
GO

