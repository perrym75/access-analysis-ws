
CREATE trigger TI_M_POST_DATA on VW_M_POST_DATA instead of insert
as
begin
	if exists( select * from M_POST_DATA m inner join inserted i on m.PARENT_ID = i.PARENT_ID and m.[KEY] = i.[KEY] )
		update M_POST_DATA set [VALUE] = i.[VALUE]
			from M_POST_DATA m inner join inserted i on m.PARENT_ID = i.PARENT_ID and m.[KEY] = i.[KEY];
	else
		insert into M_POST_DATA( [PARENT_ID], [KEY], [VALUE] ) select [PARENT_ID], [KEY], [VALUE] from inserted;
end;
GO

