
create procedure "PD_SECURITY_RULE" @ioSECURITY_RULE_ID INTEGER
as
begin
	delete from "SECURITY_RULE" where "SECURITY_RULE_ID" = @ioSECURITY_RULE_ID;
end;
GO

