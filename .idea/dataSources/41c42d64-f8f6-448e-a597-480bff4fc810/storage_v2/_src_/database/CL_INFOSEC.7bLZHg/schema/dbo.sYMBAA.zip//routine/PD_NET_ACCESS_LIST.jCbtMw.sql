
create procedure "PD_NET_ACCESS_LIST" @ioNET_ACCESS_LIST_ID INTEGER
as
begin
	delete from "NET_ACCESS_LIST" where "NET_ACCESS_LIST_ID" = @ioNET_ACCESS_LIST_ID;
end;
GO

