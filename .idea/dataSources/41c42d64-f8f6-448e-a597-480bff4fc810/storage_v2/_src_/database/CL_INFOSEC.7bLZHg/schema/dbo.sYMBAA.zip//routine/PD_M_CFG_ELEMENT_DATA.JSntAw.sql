
create procedure "PD_M_CFG_ELEMENT_DATA" @ioPARENT_ID INTEGER,
@ioKEY NVARCHAR
as
begin
	delete from "M_CFG_ELEMENT_DATA" where "PARENT_ID" = @ioPARENT_ID and 
	"KEY" = @ioKEY;
end;
GO

