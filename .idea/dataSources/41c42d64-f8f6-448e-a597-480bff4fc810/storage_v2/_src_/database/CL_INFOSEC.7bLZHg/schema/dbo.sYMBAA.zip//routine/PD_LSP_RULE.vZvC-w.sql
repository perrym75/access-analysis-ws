
create procedure "PD_LSP_RULE" @ioLSP_RULE_ID INTEGER
as
begin
	delete from "LSP_RULE" where "LSP_RULE_ID" = @ioLSP_RULE_ID;
end;
GO

