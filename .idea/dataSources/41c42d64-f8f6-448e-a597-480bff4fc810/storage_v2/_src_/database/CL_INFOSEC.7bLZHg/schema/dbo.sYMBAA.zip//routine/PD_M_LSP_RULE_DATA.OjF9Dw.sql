
create procedure "PD_M_LSP_RULE_DATA" @ioPARENT_ID INTEGER,
@ioKEY NVARCHAR
as
begin
	delete from "M_LSP_RULE_DATA" where "PARENT_ID" = @ioPARENT_ID and 
	"KEY" = @ioKEY;
end;
GO

