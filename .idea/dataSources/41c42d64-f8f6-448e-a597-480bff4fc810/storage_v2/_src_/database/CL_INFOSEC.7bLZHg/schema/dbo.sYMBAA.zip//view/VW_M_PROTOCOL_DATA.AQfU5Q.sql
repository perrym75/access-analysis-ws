
create view VW_M_PROTOCOL_DATA as select * from M_PROTOCOL_DATA;
GO

